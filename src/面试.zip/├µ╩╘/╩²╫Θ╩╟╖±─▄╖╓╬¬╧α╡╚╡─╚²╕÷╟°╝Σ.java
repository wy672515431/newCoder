package 面试;

public class 数组是否能分为相等的三个区间 {
        public static boolean solve(int[] a){
                int sum = 0;
                for(int i=0;i<a.length;i++)
                        sum+=a[i];
                if(sum%3!=0)
                        return false;
                int cnt = 0;
                int tem = 0;
                for(int i=0;i<a.length;i++){
                        tem = tem+a[i];
                        if(tem == sum/3){
                                cnt++;
                                tem = 0;
                        }
                }
                if(cnt!=3)
                        return false;
                else
                        return  true;
        }

        public static void main(String[] args) {
                int[] a = {-1,3,-4,-2,1};
                System.out.print(solve(a));
        }
}
