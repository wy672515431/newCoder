package 面试;

/***
 * 子序列
 */
public class 最长递增子序列 {
        public int lengthOfLIS(int[] nums) {
                if(nums.length == 0)
                        return 0;
                int cnt = 0;
                int[] dp = new int[nums.length];
                dp[0] = nums[0];
                for(int i=1;i<nums.length;i++){
                        if(nums[i]>dp[cnt]){
                                dp[++cnt] = nums[i];
                        }else{
                                int pos = lowerBound(dp,nums[i],cnt);
                                dp[pos] = nums[i];
                        }
                }
                return  cnt+1;
        }

        /***
         * 找到第一个大于等于target的下标
         * @param dp
         * @param target
         * @return
         */
        public int lowerBound(int[] dp,int target,int cnt){
                int low = 0;
                int high = cnt;
                int mid;
                while (low<high){
                        mid =(low+high)>>1;
                        if(dp[mid]>=target)
                                high = mid;
                        else
                                low = mid+1;
                }
                return low;
        }
}
